<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>lotery</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<style>
  body{
    background-image:url(shop5.jpg);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }
  h2{
    font-weight: bold;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
font-size: 31px;
  }
  i{
    font-size: 19px;
  }
  h3{
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-weight: bold;
  }
  p{
    font-size: 17px;
    font-family: Arial, Helvetica, sans-serif;
  }
  .container-fluid{
    padding-top: 70px;
  }
  .navbar{
    position:fixed;
    z-index: 3;
    width:100%;
  }
  nav a img{
    width: 50px;
  }
  a{
    font-weight:bold;
  }
</style>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-primary">
  <a class="navbar-brand" href="#"><img src="logo.png" alt=""></a>
  <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
      aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavId">

    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <h3 class="text-white text-center">facebook lotery</h3>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      
    <a name="" id="" class="btn bg-white text-primary" href="index.php" role="button"><strong>Home</strong></a>

    </form>
  </div>
</nav>
 <div class="container-fluid">
   <div class="row p-1">
       <div class="container-fluid bg-primary">
           <h3 class="text-white text-center">IMPORTANT NOTICE</h3>
       <h3 class="text-white">Instagram Spam</h3>
  <p class="text-white">
Scammers are reaching out to Lottery Instagram subscribers and posing as the Lottery! Be sure to 
manage your privacy settings so that your information will not be accessible to these individuals.
 When on the Lottery's Instagram page, a scammer only needs to click on subscribers to see everyone 
 that has not set their privacy settings to private. It's good practice to do this across all social 
 media platforms that you use. Be aware! We will never contact you about winning a prize via Instagram. 
 
  </p>
  </div>
   </div>
   <div class="row p-1">
       <div class="container-fluid bg-primary">
       <h3 class="text-white">Overseas Scam</h3>
  <p class="text-white">
Players are getting a call from an overseas telephone number (prefix 876) and being asked why they haven't claimed their winnings. This is a SCAM. 
The only time the Lottery Drawing Manager will contact a winner is for Bonus Draws and will always identify herself and ask you to come claim at one of 
the four Lottery Claims Offices. A representative from the Lottery will never contact you unsolicited. 
The Lottery will never ask you to give us up-front money to process your claim.
  </p>
  </div>
   </div>
   <div class="row p-1">
       <div class="container-fluid bg-primary">
       <h3 class="text-white">E-Mail Lottery - Canada & Powerball Scam</h3>
  <p class="text-white">
There is an email scam that is claiming that the recipient is the winner of E-MAIL LOTTERY, held in Canada, in "conjunction" with Powerball Lottery. In order to claim the prize, the recipient is asked to contact a representative 
in South Africa and provide personal information. DO NOT REPLY TO THIS SCAM.
This is a documented scam and has been reported to the Federal Trade Commission and MUSL for Powerball. 
To view a copy of the letter and other examples of letters and notices that are scams, see below. Check back often to be in the know. 

  </p>
  </div>
   </div>
 </div>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

</html>